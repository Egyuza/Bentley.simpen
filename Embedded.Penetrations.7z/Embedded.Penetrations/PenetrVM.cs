﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Prism.Mvvm;

namespace Embedded.Penetrations
{
public class PenetrVM : BindableBase
{
    public PenetrVM()
    {
        
    }
}
}
